package library;

import org.junit.runner.RunWith;
import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.*;
@RunWith(Karate.class)
@KarateOptions(tags= {"@readdatacsv"})
public class Utility {
	// TODO Auto-generated method stub

}


